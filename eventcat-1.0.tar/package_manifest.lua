local manifest = {
	files = {
  ["eventcat.lua"] = "/bin/eventcat.lua",
	},
}
return manifest
