local manifest = {
	files = {
  ["binser.lua"] = "/lib/binser.lua",
	},
}
return manifest
