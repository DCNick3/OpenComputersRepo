local manifest = {
	files = {
  ["libmapped-screen.lua"] = "/lib/libmapped-screen.lua"
	},
}
return manifest
