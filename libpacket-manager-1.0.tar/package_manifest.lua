local manifest = {
	files = {
		["libpacket_manager.lua"]="/lib/libpacket_manager.lua",
	},
}
return manifest
