local manifest = {
	files = {
		["serprint.lua"]="/lib/serprint.lua",
	},
}
return manifest
