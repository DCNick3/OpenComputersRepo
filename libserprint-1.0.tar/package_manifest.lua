local manifest = {
	files = {
		["serprint.lua"]="/usr/lib/serprint.lua",
	},
}
return manifest
