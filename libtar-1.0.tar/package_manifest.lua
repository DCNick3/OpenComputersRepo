local manifest = {
	files = {
		["tar.lua"]="/lib/tar.lua",
	},
}
return manifest
