local manifest = {
	files = {
		["tar.lua"]="/usr/lib/tar.lua",
	},
}
return manifest
