local manifest = {
	files = {
  ["uuid.lua"]="/lib/uuid.lua",
	},
}
return manifest
