local manifest = {
	files = {
		["var_dump.lua"]="/usr/lib/var_dump.lua",
	},
}
return manifest
