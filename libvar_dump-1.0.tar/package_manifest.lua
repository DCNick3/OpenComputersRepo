local manifest = {
	files = {
		["var_dump.lua"]="/lib/var_dump.lua",
	},
}
return manifest
