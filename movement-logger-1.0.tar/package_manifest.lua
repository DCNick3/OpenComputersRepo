local manifest = {
	files = {
 ["movement-logger.lua"]="/bin/movement-logger.lua"
	},
}
return manifest
