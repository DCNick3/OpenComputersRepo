local manifest = {
	files = {
		["pm.lua"]="/bin/pm.lua",
	},
}
return manifest
