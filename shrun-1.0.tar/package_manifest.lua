local manifest = {
	files = {
  ["shrun.lua"]="/bin/shrun.lua"
	},
}
return manifest
