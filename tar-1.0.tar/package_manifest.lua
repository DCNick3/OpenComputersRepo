local manifest = {
	files = {
  ["tar.lua"] = "/bin/tar.lua"
	},
}
return manifest
