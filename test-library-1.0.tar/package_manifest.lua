local manifest = {
	files = {
		["test.filea"]="/tmp/libtestfilea",
		["test.fileb"]="/tmp/libtestfileb",
	},
}
return manifest
