local manifest = {
	files = {
		["test.filea"]="/tmp/testfilea",
		["test.fileb"]="/tmp/testfileb",
	},
}
return manifest
